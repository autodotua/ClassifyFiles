﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace ClassifyFiles.UI
{
    /// <summary>
    /// CookieWindow.xaml 的交互逻辑
    /// </summary>
    public partial class BlackWhiteListWindow : WindowBase
    {
   
        public BlackWhiteListWindow()
        {
            InitializeComponent();
            //VirtualizingPanel.SetIsVirtualizing(tree, false);

        }

        private void Line_Deleted(object sender, EventArgs e)
        {
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
         
        }

        private void ContextMenu_Opened(object sender, RoutedEventArgs e)
        {
       
            

        }

        private void menuId_Click(object sender, RoutedEventArgs e)
        {

        }


        private void menuXPath_Click(object sender, RoutedEventArgs e)
        {
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
      
            Close();
        }

        private async void SearchButton_Click(object sender, RoutedEventArgs e)
        {
        }


        private void menuPath_Click(object sender, RoutedEventArgs e)
        {
        }

        private async void WindowBase_Loaded(object sender, RoutedEventArgs e)
        {
        }
    }

  
}

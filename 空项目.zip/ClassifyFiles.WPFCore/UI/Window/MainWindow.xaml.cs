﻿using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using ClassifyFiles.Data;
using System;
using System.Windows.Input;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace ClassifyFiles.UI
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : WindowBase
    {

        public MainWindow()
        {
            InitializeComponent();
            //item.Reset = ResetItem;

#if DEBUG
            Button btn = new Button();
            btn.Content = "测试";
            outGrd.Children.Add(btn);
            btn.HorizontalAlignment = HorizontalAlignment.Right;
            btn.VerticalAlignment = VerticalAlignment.Top;
            btn.Click += TestButton_Click;
            Grid.SetColumn(btn, 1);
#endif
        }

        private async void TestButton_Click(object sender, RoutedEventArgs e)
        {
            AppDbContext db = new AppDbContext("D:\\Temp\\test.db");
            db.Logs.Add(new Log() { Time = DateTime.Now, Message = "dsds" });
            await db.SaveChangesAsync();
            var a =await db.Logs.FirstOrDefaultAsync();
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void SettingMenuItem_Click(object sender, RoutedEventArgs e)
        {
            SettingWindow win = new SettingWindow() { Owner = this };
            win.ShowDialog();
        }

        private void ShutdownMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void ScriptHelperMenuItem_Click(object sender, RoutedEventArgs e)
        {
        }

        private async void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            await aboutDialog.Show();
        }

        private void AllHistoryMenuItem_Click(object sender, RoutedEventArgs e)
        {
        }

        private async void ExportMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }
        private async void ImportMenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void LogsMenuItem_Click(object sender, RoutedEventArgs e)
        {
            new LogWindow().Show();
        }
    }
}

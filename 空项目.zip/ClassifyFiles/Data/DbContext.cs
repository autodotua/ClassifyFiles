﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassifyFiles.Data
{
    public class AppDbContext : DbContext
    {
        public string DbPath { get; }
        private static bool _created = false;
        /// <summary>
        /// 从配置文件读取链接字符串
        /// </summary>
        public AppDbContext(string dbPath) :
            base()
        {
            DbPath = dbPath;
            if (!_created)
            {
                _created = true;
                Database.EnsureDeleted();
                Database.EnsureCreated();
            }
        }

        public DbSet<Log> Logs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite(@$"Data Source={DbPath}");
            base.OnConfiguring(optionsBuilder);
        }

    }
}

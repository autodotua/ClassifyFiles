﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace ClassifyFiles.Data
{
    public class Log : IDbModel
    {
        public int ID { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public DateTime Time { get; set; }
        public string Message { get; set; }

        public object Clone()
        {
            throw new NotImplementedException();
        }
    }
}

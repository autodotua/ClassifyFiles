# 

## 介绍



## 截图

![image](/Screenshots/MainWindow.png)

## 特性

- 使用.Net Framework 4.8 + WPF 开发
- 使用MD风格的界面
- 支持GET和POST
- 支持HTML和JSON
- 支持中文和英文，支持扩展更多语言
- 能够跟随系统亮色/暗色模式进行自动切换



## 更新日志

### 2019-12-25

开始项目
